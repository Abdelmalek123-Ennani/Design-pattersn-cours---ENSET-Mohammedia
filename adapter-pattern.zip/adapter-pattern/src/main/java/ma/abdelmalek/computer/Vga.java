package ma.abdelmalek.computer;

public interface Vga {

    void print(String message);
}
