package ma.abdelmalek.computer;

public interface Hdmi {
    void view(byte[] data);
}
