package ma.abdelmalek;

public class TemplateClassImpl2 extends TemplateClass {
    @Override
    protected int etape1() {
        return 4;
    }

    @Override
    protected int etape2() {
        return 7;
    }
}
