package ma.abdelmalek;

public class TemplateClassImpl extends TemplateClass {
    @Override
    public int etape1() {
        return 6;
    }

    @Override
    public int etape2() {
        return 80;
    }
}
