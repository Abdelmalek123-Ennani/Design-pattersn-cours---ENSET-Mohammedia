package ma.abdelmalek.model;

public enum AccountType {
    CURRENT_ACCOUNT,SAVING_ACCOUNT
}
