package ma.abdelmalek;

public interface Observer {
    void update(int state);
}
