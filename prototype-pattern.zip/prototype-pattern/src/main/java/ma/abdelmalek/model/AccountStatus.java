package ma.abdelmalek.model;

public enum AccountStatus {
    CREATED, ACTIVATED, SUSPENDED, BLOCKED
}
