package ma.abdelmalek;

public abstract class Composant {
    public abstract void open();
}
