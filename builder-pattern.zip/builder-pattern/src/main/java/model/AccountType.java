package model;

public enum AccountType {
    CURRENT_ACCOUNT,SAVING_ACCOUNT
}
