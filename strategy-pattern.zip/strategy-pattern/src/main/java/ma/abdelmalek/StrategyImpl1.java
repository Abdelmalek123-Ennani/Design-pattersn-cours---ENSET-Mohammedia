package ma.abdelmalek;

public class StrategyImpl1 implements Strategy {
    @Override
    public void operaionStrategy() {
        System.out.println("Application de Strategy 1");
    }
}
