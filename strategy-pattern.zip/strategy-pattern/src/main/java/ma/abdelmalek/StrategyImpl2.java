package ma.abdelmalek;

public class StrategyImpl2 implements Strategy {
    @Override
    public void operaionStrategy() {
        System.out.println("Application de Strategy 2");
    }
}
