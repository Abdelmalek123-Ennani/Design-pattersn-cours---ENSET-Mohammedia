package ma.abdelmalek;

public interface Strategy {
    public void operaionStrategy();
}
