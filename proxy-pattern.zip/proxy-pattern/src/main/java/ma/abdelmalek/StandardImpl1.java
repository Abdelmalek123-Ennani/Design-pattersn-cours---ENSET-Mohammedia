package ma.abdelmalek;

public class StandardImpl1 implements Standard{
    @Override
    public void process() {
        System.out.println("**************************");
        System.out.println("Process.....StandardImpl 1");
        System.out.println("***************************");
    }
}
