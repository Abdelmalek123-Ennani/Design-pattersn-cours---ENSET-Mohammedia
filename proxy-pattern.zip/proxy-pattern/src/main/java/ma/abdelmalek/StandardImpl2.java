package ma.abdelmalek;

public class StandardImpl2 implements Standard{
    @Override
    public void process() {
        System.out.println("**************************");
        System.out.println("Process.....StandardImpl 2");
        System.out.println("***************************");
    }
}
