package ma.abdelmalek;

public interface Standard{
    public void process();
}
